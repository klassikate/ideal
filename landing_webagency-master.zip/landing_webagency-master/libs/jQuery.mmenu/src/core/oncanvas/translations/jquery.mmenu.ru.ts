(function( $ ) {

	const _PLUGIN_ 	= 'mmenu';
	const _LANG_ 	= 'ru';

	$[ _PLUGIN_ ].i18n({
		'Menu': 'Меню'
	}, _LANG_ );

})( jQuery );

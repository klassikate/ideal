(function( $ ) {

	const _PLUGIN_ 	= 'mmenu';
	const _LANG_	= 'de';

	$[ _PLUGIN_ ].i18n({
		'Menu': 'Menü'
	}, _LANG_ );

})( jQuery );